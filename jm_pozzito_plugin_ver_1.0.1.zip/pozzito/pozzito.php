<?php
/**
 * @version     $Id: pozzito.php
 * @package     Joomla.Plugin
 * @subpackage  Content.Joomla
 * @author      Alen Begovic at Pozzito.com
 * @copyright   Copyright (C) 2017 Pozzito.com. All rights reserved.
 * @license     GNU General Public License version 3; see LICENSE.txt
 */

defined('_JEXEC') or die('Restricted access! Hacking attempt has been alerted!');


/**
* Global Constants (Compatiblitiy with old PHP version - using DEFINE istead of CONST - STATIC SCALAR EXPRESSIONS)
*/
define('POZZITO_WIDGET_SCRIPT_URI', "plugins/content/pozzito/scripts/jm_pozzito_widget.js"); //relative to JM Base Path (Juri::base()) - URI
define('POZZITO_SETTINGS_SCRIPT_URI', "plugins/content/pozzito/scripts/jm_pozzito_settings.js"); //relative to JM Base Path (Juri::base()) - URI
define('POZZITO_SETTINGS_SCRIPT_FULL_PATH', JPATH_PLUGINS . "/content/pozzito/scripts/jm_pozzito_settings.js"); //absolute path to JS File - PATH


/**
* CONTENT PLUGIN (class name must be plg (Plg)<PluginGroup><PluginName>)
*/
class plgContentPozzito extends JPlugin
{

    /**
    * Fields and Constants
    */
    //const POZZITO_WIDGET_SCRIPT_URI =  "plugins/content/pozzito/scripts/jm_pozzito_widget.js"; //relative to JM Base Path (Juri::base())
    //const POZZITO_SETTINGS_SCRIPT_URI =  "plugins/content/pozzito/scripts/jm_pozzito_settings.js"; //relative to JM Base Path (Juri::base())
    //const POZZITO_SETTINGS_SCRIPT_FULL_PATH = JPATH_PLUGINS . "/content/pozzito/scripts/jm_pozzito_settings.js";


    /**
     * Load the language file on instantiation. Note this is only available in Joomla 3.1 and higher.
     * If you want to support 3.0 series you must override the constructor
     *
     * @var    boolean
     */
    protected $autoloadLanguage = true;


    /**
     * Plugin that loads module positions within content
     *
     * @param   string   $context   The context of the content being passed to the plugin.
     * @param   object   &$article  The article object.  Note $article->text is also available
     * @param   mixed    &$params   The article params
     * @param   integer  $page      The 'page' number
     *
     * @return  mixed   true if there is an error. Void otherwise.
     *
     */
    public function onContentPrepare()
    {
        //Get Params from Admin
        $app_id = $this->params->get('app_id', '');
        $api_key = $this->params->get('api_key', '');

        //JM Error handling
        //$this->HandleSettings($app_id, $api_key);

        //Create Pozzito Settings Script with Params from DB
        $this->CreatePozzitoSettingsFile($app_id, $api_key);
        //Load POZZITO SETTINGS JS (API KEY and APP ID)
        $this->LoadPozzitoSettingsScript();
        //Load POZZITO WIDGET JS
        $this->LoadPozzitoWidget();

        
        return true;
    }

    /**
     * Initialise the Plugin Scripts
     *
     * @param   string  $id  The id of the field.
     *
     * @return  Boolean	True on success, false otherwise
     *
     * @throws  Exception
     *
     * @since  1.0
     */
    public function onInit()
    {
        //Get Params from Admin
        $app_id = $this->params->get('app_id', '');
        $api_key = $this->params->get('api_key', '');

        //JM Error handling
        //$this->HandleSettings($app_id, $api_key);

        //Create Pozzito Settings Script with Params from DB
        $this->CreatePozzitoSettingsFile($app_id, $api_key);
        //Load POZZITO SETTINGS JS (API KEY and APP ID)
        $this->LoadPozzitoSettingsScript();
        //Load POZZITO WIDGET JS
        $this->LoadPozzitoWidget();


        return true;
    }


    /**
     * Handle Pozzito Widget Settings with JM Error Message
     */
    private function HandleSettings($app_id, $api_key)
    {
        //JM ERROR HANDLING
        if ($app_id == null || $app_id == '') {
            throw new Exception(JText::_('PLG_RECAPTCHA_ERROR_NO_APP_ID'));
            return false;
        }
        if ($api_key == null || $api_key == '') {
            throw new Exception(JText::_('PLG_RECAPTCHA_ERROR_NO_API_KEY'));
            return false;
        }

        return true;
    }


    /**
     * Loads the Pozzito Widget Scripts into JM Head
     */
    private function LoadPozzitoWidget()
    {
        
        //JM ERROR HANDLING
        /*
        $script = JText::_('PLG_POZZITO_WIDGET_SCRIPT_URI_PATH');

        if ($script == null || $script == '')
        {
            throw new Exception(JText::_('Pozzito Widget Path is not set correctly'));
        }
        */


        $script = POZZITO_WIDGET_SCRIPT_URI;
        $url = Juri::base() . $script ;  //POZZITO_WIDGET_SCRIPT;
        

        //ADD/LOAD Widget into JM HEAD TAG
        $document = JFactory::getDocument();
        JHTML::script($url, false);
        $document->addScript($url);
        

        return true;
    }

    
    /**
     * Create the Pozzito Settings JS file with APP ID & APP KEY from DB
     */
    private function CreatePozzitoSettingsFile($app_id, $api_key)
    {

        //If initial values are not set - no widget baby :)
        if ($app_id != null && $api_key != null) {


            //Construct Settings => Pozzito Config JS Object
            $settings_string =  " var pozzitoConfig = { apiKey : \"". $api_key . "\", appId : \"" . $app_id .  "\" }; ";
       

            file_put_contents(POZZITO_SETTINGS_SCRIPT_FULL_PATH, $settings_string);
            //$response = file_exists($url);
        }
    }

    /**
     * Loads the Pozzito Settings Scripts into JM Head
     */
    private function LoadPozzitoSettingsScript()
    {
        $script = POZZITO_SETTINGS_SCRIPT_URI; //JText::_('PLG_POZZITO_WIDGET_SCRIPT_URI_PATH');
        $url = Juri::base() . $script;

        $document = JFactory::getDocument();

        JHTML::script($url, false);
        $document->addScript($url);

        return true;
    }
}
